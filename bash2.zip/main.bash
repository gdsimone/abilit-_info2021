# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
echo "Hello World";

# es 1
alias cp = 'cp -i'
alias mv = 'mv -i'
alias rm = 'rm -i'
alias ld = 'ls -l -t'
alias la = 'ls -r'

#es 2
ls | wc -l

#es 3
#1.cerca il file esercitazione.txt ( comando find directory-name search-expression) 
#2. cerca il file \*.py seguendo il path. Poi cerca 
#3. scarta il comando che viene scritto

#es 4

#es 5
#assicura che il processo in esecuzione non venga terminato quando si esce dal terminale

#es 6
#un editor a linea di comando si usa quando si deve solo entrare in un file per una rapida modifica
#Un editor grafico consente di modificare e manipolare immagini grafiche
#un IDE è un software che consente lo sviluppo del codice sorgente di un programma 
